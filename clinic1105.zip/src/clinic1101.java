import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

//import com.mysql.cj.xdevapi.PreparableStatement;

import java.sql.Statement;

//import java.nio.charset.StandardCharsets;

public class clinic1101 {
    private static final String URL = "jdbc:mysql://localhost:3306/1141029_clinic";
    private static final String USER = "root";
    private static final String PASSWORD = "84447521";

    public static void main(String[] args) {
        // ? �ϥ� UTF-8 Scanner�]�קK�����J�ýX�^
        Scanner scanner=new Scanner(System.in,"BIG5");
        Connection conn = null;

        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            
            System.out.println("? MySQL �s�u���\�I");

            while (true) {
                System.out.println("\n�п�ܾާ@:");
                System.out.println("0 - �h�X");
                System.out.println("1 - �w���ݶE���");
                System.out.println("2 - �s�W��v");
                System.out.println("3 - �d����v");
                System.out.println("4 - �d�ݯf�H");
                System.out.println("5 - �d�ݹw�����p");
                System.out.println("6 - ���w�����p");
                System.out.println("7 - �s�W�f��");
                System.out.println("8 - �d�ݥI�ک��ӤΪ��p");
                System.out.println("9 - ���I�ڪ��p");
                System.out.print("��J�ﶵ: ");
                String choice = scanner.nextLine();

                if ("0".equals(choice)) {
                    System.out.println("�h�X�{��");
                    break;
                
                } else if ("1".equals(choice)){
                    System.out.print("��J������(ex:A123456789): ");
                    PreparedStatement ps = conn.prepareStatement("SELECT patient_id FROM patients WHERE national_id = ?");
                    String national_id = scanner.nextLine();
                    ps.setString(1, national_id);
                    ResultSet rs = ps.executeQuery();
                    int a_id = -1;
                    
                    /*if(rs.next()){
                        count = rs.getInt(1);
                    }*/
                    if (rs.next()) {
                        a_id = rs.getInt("patient_id");
                        System.out.println("? �f�H�w�s�b , ID = " + a_id);
                    } else {
                        System.out.println("?�d�L���H �зs�W�f�H");
                        System.out.print("��J�m�W: ");
                        String p_name = scanner.nextLine();
                        System.out.print("��J�ʧO(M/F): ");
                        String p_gender = scanner.nextLine();
                        System.out.print("��J�ͤ�(ex:1999-12-30): ");
                        String p_date = scanner.nextLine();
                        System.out.print("��J�q��(ex:09xxxxxxxx): ");
                        String p_phone = scanner.nextLine();

                        // ��@ SQL �۰� +1 ���J
                        String insertSQL = "INSERT INTO patients (national_id, name, gender, birth_date, phone) VALUES (?, ?, ?, ?, ?)";
                        try (PreparedStatement pstmt = conn.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS)) {
                            pstmt.setString(1, national_id);
                            pstmt.setString(2, p_name);
                            pstmt.setString(3, p_gender);
                            pstmt.setString(4, p_date);
                            pstmt.setString(5, p_phone);
                            int rows = pstmt.executeUpdate();
                            System.out.println("�f�H�s�W���\�A�@ " + rows + " ����ơC");

                            ResultSet keyRs = pstmt.getGeneratedKeys();
                            if (keyRs.next()) {
                                a_id = keyRs.getInt(1);
                                System.out.println("? �s�f�H patient_id = " + a_id);
                            } else {
                                System.out.println("? ERROR: �S���o patient_id (�s�W����)");
                                return; // ����{���קK���~
                            }
                        }                        
                    }
                    System.out.println("����v(����):1  �L��v(�~��):2");
                    System.out.print("�w����v: ");
                    String a_doctor = scanner.nextLine();
                    //String a_patient = "1";

                    System.out.print("�w�����(ex:1999-01-01): ");  //�榡01-01?
                    String a_date = scanner.nextLine();
                    String insertSQL = "INSERT INTO appointments (patient_id, doctor_id, appointment_date) VALUES (?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS)) {
                        pstmt.setInt(1, a_id);  //�s���~���h��
                        pstmt.setInt(2, Integer.parseInt(a_doctor));
                        pstmt.setString(3, a_date);
                        pstmt.executeUpdate();
                    }
                    System.out.println("�w�����\");
                
                } else if ("2".equals(choice)) {
                    System.out.print("��J��m�W: ");
                    String d_name = scanner.nextLine();
                    System.out.print("��J��O(ex:����): ");
                    String d_specialty = scanner.nextLine();
                    System.out.print("��J���Ӹ�(ex:D0001): ");
                    String d_license = scanner.nextLine();


                    // ��@ SQL �۰� +1 ���J  ��L���令�D����N�i�H�u��J�Ǹ���m�W
                    // �s�W�f�H���
                    String insertSQL = "INSERT INTO doctors (name, specialty, license_no) VALUES (?, ?, ?)";
                
                    try (PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
                        pstmt.setString(1, d_name);
                        pstmt.setString(2, d_specialty);
                        pstmt.setString(3, d_license);  //����D000X
                        int rows = pstmt.executeUpdate();
                        System.out.println("�s�W���\�A�@ " + rows + " ����ơC");
                    }

                } else if ("3".equals(choice)) {
                    String querySQL = "SELECT doctor_id, name, specialty, license_no FROM doctors";
                    try (PreparedStatement pstmt = conn.prepareStatement(querySQL);
                            ResultSet rs = pstmt.executeQuery()) {
                        System.out.println("�Ҧ���v�C��:");
                        java.sql.ResultSetMetaData meta = rs.getMetaData();
                        int columnCount = meta.getColumnCount();
                        //Ū�����G
                        System.out.println("");
                        while (rs.next()) {
                            for (int i = 1; i <= columnCount; i++) {
                                System.out.print(rs.getString(i) + "\t");
                            }
                            System.out.println();
                        }

                    }
                
                } else if ("4".equals(choice)) {
                    String querySQL = "SELECT patient_id, national_id, name, gender, birth_date, phone FROM patients";
                    try (PreparedStatement pstmt = conn.prepareStatement(querySQL);
                            ResultSet rs = pstmt.executeQuery()) {
                        System.out.println("�Ҧ��Ȥ�C��:");
                        java.sql.ResultSetMetaData meta = rs.getMetaData();
                        int columnCount = meta.getColumnCount();
                        //Ū�����G
                        System.out.println("");
                        while (rs.next()) {
                            for (int i = 1; i <= columnCount; i++) {
                                System.out.print(rs.getString(i) + "\t");
                            }
                            System.out.println();
                        }

                    }
                } else if ("5".equals(choice)){
                    String sql = "select * from report01";

                    PreparedStatement pstmt_rp01 = conn.prepareStatement(sql);
                    ResultSet rs = pstmt_rp01.executeQuery();

                    java.sql.ResultSetMetaData meta = rs.getMetaData();
                    int columnCount = meta.getColumnCount();
                    // Ū�����G
                    while (rs.next()) {
                    for (int i = 1; i <= columnCount ; i++) {
                        System.out.print(rs.getString(i) + "\t");
                    }
                    System.out.println();
                    }

                } else if ("6".equals(choice)){
                    System.out.print("��J������(ex:A100000001): ");
                    String national_id = scanner.nextLine();
                    PreparedStatement ps = conn.prepareStatement("SELECT patient_id FROM patients WHERE national_id = ?");
                    ps.setString(1, national_id);
                    ResultSet rs = ps.executeQuery();
                    int a_id = -1;
                    if (rs.next()) {
                        a_id = rs.getInt("patient_id");
                        //System.out.println(" �Ǹ�ID = " + a_id);
                    } else {
                        System.out.println("?�d�L���H �зs�W�f�H");
                        return; // ����{���קK���~
                    }

                    System.out.print("��J���(ex:1999-01-01): ");
                    String a_date = scanner.nextLine();
                    //System.out.println(a_date);
                    //�P�_�f�H�O�_�b�o�Ѧ��w��
                    PreparedStatement ps2 = conn.prepareStatement("SELECT appointment_id, status FROM appointments WHERE appointment_date = ? AND patient_id = ?");
                    ps2.setString(1, a_date);
                    ps2.setInt(2, a_id);
                    ResultSet rs2 = ps2.executeQuery();
                    if (!rs2.next()) {
                        System.out.println("�d�L���H�w��");
                        return; // ����{���קK���~

                    }

                    int appId = rs2.getInt("appointment_id");
                    String oldStatus = rs2.getString("status");
                    System.out.println(" ���w��: appointment_id = " + appId + " �ثe���A = " + oldStatus);

                    //��sstatus

                    System.out.print("�п�J��s�᪬�A (�w�w��/�w�ݶE/����): ");
                    String newStatus = scanner.nextLine();
                    String updateSQL = "UPDATE appointments SET status = ? WHERE appointment_id = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(updateSQL)) {
                        pstmt.setString(1, newStatus);
                        pstmt.setInt(2, appId);
                        int rows = pstmt.executeUpdate();
                        System.out.println("��s���\�A�@ " + rows + " ����ơC");

                    } 
                } else if ("7".equals(choice)){
                    System.out.print("��J������(ex:A100000001): ");
                    String national_id = scanner.nextLine();
                    PreparedStatement ps = conn.prepareStatement("SELECT patient_id FROM patients WHERE national_id = ?");
                    ps.setString(1, national_id);
                    ResultSet rs = ps.executeQuery();
                    int a_id = -1;
                    if (rs.next()) {
                        a_id = rs.getInt("patient_id");
                        //System.out.println(" �Ǹ�ID = " + a_id);
                    } else {
                        System.out.println("?�d�L���H �зs�W�f�H");
                        return; // ����{���קK���~
                    }

                    System.out.print("��J���(ex:1999-01-01): ");
                    String a_date = scanner.nextLine();
                    //System.out.println(a_date);
                    //�P�_�f�H�O�_�b�o�Ѧ��w��
                    PreparedStatement ps2 = conn.prepareStatement("SELECT appointment_id, status FROM appointments WHERE appointment_date = ? AND patient_id = ?");
                    ps2.setString(1, a_date);
                    ps2.setInt(2, a_id);
                    ResultSet rs2 = ps2.executeQuery();
                    if (!rs2.next()) {
                        System.out.println("�d�L���H�w��");
                        return; // ����{���קK���~

                    }

                    int appId = rs2.getInt("appointment_id");
                    String oldStatus = rs2.getString("status");
                    System.out.println(" ���w��: appointment_id = " + appId + " �ثe���A = " + oldStatus);

                    //�s�W�ݾ���

                    System.out.print("�g��: ");
                    String m_symptom = scanner.nextLine();
                    System.out.print("�̭]ID  ex(0:�L 1:�y�P�̭] 2:A���x�� 3:�a���w�l): ");
                    String m_vaccineid = scanner.nextLine();

                    //�s�W��SQL
                    PreparedStatement ps3 = conn.prepareStatement("INSERT INTO medical_records (appointment_id, symptoms, vaccine_id) VALUES (?, ?, ?)"
);
                    ps3.setInt(1, appId);
                    ps3.setString(2, m_symptom);    //�g��
                    ps3.setString(3, m_vaccineid);  //�̭]ID
                    ps3.executeUpdate();
                    System.out.println("�ݶE�����w�s�W");
                    


                    PreparedStatement ps4 = conn.prepareStatement("UPDATE appointments SET status = '�w�ݶE' WHERE appointment_id = ?");
                    ps4.setInt(1, appId);
                    ps4.executeUpdate();
                    System.out.println("�w�����A�w��s���y�w�ݶE�z");

                    //���ͱb��

                    int record_id = -1;     //���]-1�h�����
                    int vaccine_id = 0;     //�w�]0�S���̭]
                    PreparedStatement ps_billing = conn.prepareStatement("SELECT record_id, vaccine_id FROM medical_records WHERE appointment_id = ?");
                    ps_billing.setInt(1, appId);
                    ResultSet rs_billing = ps_billing.executeQuery();
                    

                    if(rs_billing.next()){
                        record_id = rs_billing.getInt("record_id");
                        vaccine_id = rs_billing.getInt("vaccine_id");
                        
                    } else {
                        System.out.println("�d�L���f�� , �L�k�إ߱b��");
                        return; // ����{���קK���~
                    }
                    
                    //���̭]����
                    if (vaccine_id >= 0){
                        PreparedStatement ps_va_price = conn.prepareStatement("SELECT vaccine_price FROM vaccines WHERE vaccine_id = ?");
                        ps_va_price.setInt(1, vaccine_id);
                        ResultSet rs_va_price = ps_va_price.executeQuery();
                        System.out.println("�ǳƫإ߱b��...");
                        if(rs_va_price.next()){
                            int va_price = rs_va_price.getInt("vaccine_price");

                            int registration_fee = 200;                 //�����O
                            int total = registration_fee + va_price;    //�`���B

                            PreparedStatement ps_bill = conn.prepareStatement("INSERT INTO billing (records_id, registration_fee, vaccine_fee, paid) VALUES (?, ?, ?, 0)", Statement.RETURN_GENERATED_KEYS);
                            ps_bill.setInt(1, record_id);
                            ps_bill.setInt(2, registration_fee);
                            ps_bill.setInt(3, va_price);
                            //ps_bill.setInt(4, total);                 //SQL�۰ʥ[�` �i�H���Υ��W�h
                            int rows = ps_bill.executeUpdate();
                            
                            if (rows > 0){
                                ResultSet rs_billId = ps_bill.getGeneratedKeys();
                                if (rs_billId.next()) {
                                int billing_id = rs_billId.getInt(1);
                                System.out.println(" �b��w���\�إߡI");
                                System.out.println("�b��s��: " + billing_id);
                                System.out.println("�f���s��: " + record_id);
                                System.out.println("�����O: " + registration_fee);
                                System.out.println("�̭]�O: " + va_price);
                                System.out.println("�`���B: " + total);
                                }
                            }
                            
                        }    

                    }

                    

                    

                } else if ("8".equals(choice)){
                    String querySQL = "SELECT bill_id, records_id, national_id, registration_fee, vaccine_fee, total, paid, created_at, updated_at FROM report07";
                    try (PreparedStatement pstmt = conn.prepareStatement(querySQL);
                            ResultSet rs = pstmt.executeQuery()) {
                        System.out.println("�Ҧ��I�O�b��:");
                        java.sql.ResultSetMetaData meta = rs.getMetaData();
                        int columnCount = meta.getColumnCount();
                        //Ū�����G
                        System.out.println("");
                        while (rs.next()) {
                            for (int i = 1; i <= columnCount; i++) {

                                if(meta.getColumnLabel(i).equals("paid")){
                                    int paid = rs.getInt("paid");
                                    String status = (paid == 1) ? "�w�I��" : "���I��";
                                    System.out.print(status + "\t");
                                } else {
                                System.out.print(rs.getString(i) + "\t");
                                }
                            }
                            System.out.println();
                        }

                    }
                } else if ("9".equals(choice)){
                    System.out.print("��J������(ex:A100000001): ");
                    String national_id = scanner.nextLine();
                    //int b_paid = 0;
                    //�]����view�����Y,�p�G�W�٧令����,java�|�䤣��,�B�z��k�إ�2��veiw,�@�ӧ襤��W����ܥ�,�@�ӥέ^��O�W�M��鷺�e��
                    PreparedStatement ps = conn.prepareStatement("SELECT bill_id, paid FROM report06 WHERE national_id = ? AND paid = 0 ORDER BY bill_id DESC LIMIT 1");
                    ps.setString(1, national_id);
                    
                    ResultSet rs = ps.executeQuery();
                    if(!rs.next()) {
                        System.out.println("�S�����I�ڱb��");
                        return; // ����{���קK���~
                    }

                    int billId = rs.getInt("bill_id");
                    System.out.println("���I�ڱb��,ú�O�渹" + billId + "��");

                    System.out.print("�п�J��s�᪬�A �w�I=1 ���I=0�G");
                    int newStatus = scanner.nextInt();
                    scanner.nextLine();
                    
                    PreparedStatement ps2 = conn.prepareStatement("UPDATE billing SET paid = ? WHERE bill_id = ?");
                    ps2.setInt(1, newStatus);
                    ps2.setInt(2, billId);
                    
                    int rows = ps2.executeUpdate();
                    System.out.println("? ���\��s " + rows + " ����ơI�I�ڪ��A�w�ק�");

                } else {
                    System.out.println("�L�Ŀﶵ�A�Э��s��J�I");
                }
            }

        } catch (SQLException e) {
            System.out.println("? �������� SQL Debug:");
            e.printStackTrace();
        } finally {
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException e) {
            }
            scanner.close();
        }
    }
}
